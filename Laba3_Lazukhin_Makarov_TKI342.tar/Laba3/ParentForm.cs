﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace Laba3
{
    public partial class ParentForm : Form
    {
        public ParentForm()
        {
            InitializeComponent();
        }

        private Button btnGo;
        private Button btnInfo;
        private Button btnCheck;
        private TextBox tbMin;
        private TextBox tbMax;
        private ListBox lby;
        private ListBox lbx;
        private ListBox lbx1;
        private ListBox lby1;
        private ListBox lbMain;

        private void parentForm_Load(object sender, EventArgs e)
        {
            buttons();
            textboxes();
            lists();
            btnGo.Visible = true;
        }

        private void buttons()
        {
            BackColor = SystemColors.MenuHighlight;
            Cursor = Cursors.Hand;
            Button Buttongenerator(int x, int y, string label, bool anchor)
            {
                Button example = new Button();
                example.Location = new Point(this.Width - x, this.Height - y);
                example.Text = label;
                example.AutoSize = true;
                example.BackColor = Color.Black;
                example.Padding = new Padding(6);
                example.Font = new Font("Times New Roman", 18);
                example.Visible = false;
                example.ForeColor = Color.White;
                if (anchor == true) example.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
                return example;
            }

            Button btnInfo = Buttongenerator(100, 485, "Справка", true);
            btnInfo.Click += BtnInfo_Click;
            Controls.Add(btnInfo);


            btnGo = Buttongenerator(800, 100, "Нажмите, чтобы начать работу", false);
            btnGo.Click += btnGo_Click;
            Controls.Add(btnGo);

            Button btnCheck = Buttongenerator(100, 100, "Выгрузить", true);
            btnCheck.Click += btnCheck_Click;
            Controls.Add(btnCheck);
        }
        private void textboxes()
        {
            TextBox TextBoxgenerator(int x, int y)
            {
                TextBox example = new TextBox();
                example.Location = new Point(x, y);
                example.AutoSize = true;
                example.Visible = false;
                return example;
            }

            tbMin = TextBoxgenerator(btnGo.Left + btnGo.Width / 3, this.Height - 470);
            Controls.Add(tbMin);

            tbMax = TextBoxgenerator(btnGo.Left + 2 * btnGo.Width / 3, this.Height - 470);
            Controls.Add(tbMax);

        }

        private void lists()
        {
            ListBox ListBoxgenerator(int x, int y)
            {
                ListBox example = new ListBox();
                example.Location = new Point(x, y);
                example.Size = new Size(btnGo.Width / 3, 200);
                example.Visible = false;
                return example;
            }

            lbx = ListBoxgenerator(btnGo.Left + btnGo.Width / 3, 65);
            lbx.SelectedIndexChanged += lbx_SelectedIndexChanged;
            Controls.Add(lbx);

            lby = ListBoxgenerator(lbx.Right, 65);
            lby.SelectedIndexChanged += lby_SelectedIndexChanged;
            Controls.Add(lby);

            lbx1 = ListBoxgenerator(lby.Right, 65);
            lbx1.SelectedIndexChanged += lbx1_SelectedIndexChanged;
            Controls.Add(lbx1);

            lby1 = ListBoxgenerator(lbx1.Right, 65);
            lby1.SelectedIndexChanged += lby1_SelectedIndexChanged;
            Controls.Add(lby1);

            lbMain = ListBoxgenerator(btnGo.Left, 65);
            lbMain.Items.Add("ArcSin x");
            lbMain.Items.Add("Sqrt x");
            lbMain.Items.Add("Log_10 x");
            lbMain.Items.Add("Log_2 ((x+1)/(x-1))");
            lbMain.Items.Add("ArcCos x");
            lbMain.Items.Add("Sin x");
            lbMain.Items.Add("x^2");
            lbMain.Items.Add("Cos x");
            lbMain.Items.Add("ArcTg x");
            lbMain.Items.Add("Log_e x");
            lbMain.Items.Add("Tan x");
            lbMain.Items.Add("Log_2 x");
            Controls.Add(lbMain);
        }
    
            
        private void lby_SelectedIndexChanged(object sender, EventArgs e)
        {
            lbx.SelectedIndex = lby.SelectedIndex;
        }

        private void lby1_SelectedIndexChanged(object sender, EventArgs e)
        {
            lbx1.SelectedIndex = lby1.SelectedIndex;
        }

        private void lbx_SelectedIndexChanged(object sender, EventArgs e)
        {
            lby.SelectedIndex = lbx.SelectedIndex;
        }

        private void lbx1_SelectedIndexChanged(object sender, EventArgs e)
        {
            lby1.SelectedIndex = lbx1.SelectedIndex;
        }

       

        private void btnCheck_Click(object sender, EventArgs e)
        {
            string round(string rounding)
            {
                double temp = Double.Parse(rounding);
                temp = Math.Round(temp, 3);
                rounding = temp.ToString();
                return rounding;
            }

            lbx1.Items.Clear();
            lby1.Items.Clear();
            lbx1.Visible = true;
            lby1.Visible = true;
            string text = File.ReadAllText("Data.txt");
            char[] check = {'$', '|'};
            string xy = "$$$";
            foreach (var ch in text)
            {
                string temp = "";
                temp += ch;
                if (xy.Substring(xy.Length -  3, 3).Equals("|||"))
                {
                    xy = xy.Trim(check);
                    lbx1.Items.Add(xy);
                    xy = "$$$";
                }
                if (temp.Equals("\n"))
                {
                    xy = xy.Trim(check);
                    if (xy.IndexOf(",") > -1)
                    {
                        xy = round(xy);
                    }
                    lby1.Items.Add(xy);
                    xy = "$$$";
                }
                xy += ch;
            }


        }
            private void btnGo_Click(object sender, EventArgs e)
        {
                foreach (Control cntrl in this.Controls)
                {
                    cntrl.Visible = true;
                }
                lbx1.Visible = false;
                lby1.Visible = false;
            if (lbMain.SelectedIndex > -1)
            {
                lbx.Items.Clear();
                lby.Items.Clear();

               if (string.IsNullOrEmpty(tbMin.Text) || string.IsNullOrEmpty(tbMax.Text))
                {
                    return;
                }
                StreamWriter sr = new StreamWriter("Data.txt");
                int counter = 0;
                for (int i = Int32.Parse(tbMin.Text); i <= Int32.Parse(tbMax.Text); i += 1)
                {
                    lbx.Items.Add(i);
                    switch (lbMain.SelectedIndex)
                    {
                        case 0:
                            lby.Items.Add(Math.Asin(i));
                            break;
                        case 1:
                            lby.Items.Add(Math.Sqrt(i));
                            break;
                        case 2:
                            lby.Items.Add(Math.Log10(i));
                            break;
                        case 3:
                            if (i == 1) lby.Items.Add("Деление на 0");
                            else
                                lby.Items.Add(Math.Log((i + 1) / (i - 1), 2));
                            break;
                        case 4:
                            lby.Items.Add(Math.Acos(i));
                            break;
                        case 5:
                            lby.Items.Add(Math.Sin(i));
                            break;
                        case 6:
                            lby.Items.Add(i * i);
                            break;
                        case 7:
                            lby.Items.Add(Math.Cos(i));
                            break;
                        case 8:
                            lby.Items.Add(Math.Atan(i));
                            break;
                        case 9:
                            lby.Items.Add(Math.Log(i));
                            break;
                        case 10:
                            lby.Items.Add(Math.Tan(i));
                            break;
                        case 11:
                            lby.Items.Add(Math.Log(i, 2));
                            break;
                        default:
                            lby.Items.Add(0000000);
                            break;
                    }
                    string x = lbx.Items[counter].ToString();
                    string y = lby.Items[counter].ToString();
                    sr.Write(x);
                    sr.Write("|||");
                    sr.Write(y);
                    sr.Write("\n");
                    counter++;
                }
                
                sr.Close();
                
            }
        }

        private void BtnInfo_Click(object sender, EventArgs e)
        {
            ChildForm Child = new ChildForm();
            Child.Owner = this;
            Child.ShowDialog();
            Child.Dispose();
        }
     }

    
    public partial class ChildForm : Form
    {
        private TextBox msg;
        public ChildForm()
        {
            msg = new TextBox();
            msg.Location = new Point(0, 0);
            msg.Size = new Size(this.Width, this.Height);
            msg.Multiline = true;
            msg.Font = new Font("Times New Roman", 18);
            msg.ReadOnly = true;
            msg.Text = "Данная программа реализует автоматическое построение значений абсцисы и ординаты функции\n" +
            "на промежутке между двумя задаваемыми значениями с шагом 1. Пожалуйста, введите значение\n" +
            "нижней границы промежутка в левое заполняемое поле, а значение верхней границы промежутка\n" +
            "в правое, после чего выберите одну из доступных функций и нажмите на кнопку (Нажмите, чтобы\n" +
            "начать работу). В результате левый столбец будет заполнен значениями абсциссы а правый\n" +
            "значениями ординаты. Результаты автоматически выгружаются в файл  Data.txt откуда их можно\n" +
            "выгрузить обратно в программу с округлением по нажатию кнопки выгрузить. Результаты будут в отдельной таблице\n";
            Controls.Add(msg);
            Resize += msg_Resize;  
        }
        private void msg_Resize(object sender, EventArgs e)
        {
            msg.Size = new Size(this.Width, this.Height);
        }
    }
}

    


